a = 0
while True:
    a += 0.1
    print(a)
    if (a > 1):
        exit(0)
    print("Hello")