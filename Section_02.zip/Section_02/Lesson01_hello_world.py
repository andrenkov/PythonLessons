print("Hello World!!!")
print('"Hello World!!!"')
print("Hello ' ' World")

# an escape sequence
print("Hello ' '\" World")
print("Hello \\ World")

print(2 + 9)

print("Hi" + " Vladimir")
# the same will be printed separated by a aspace by default
print("Hi", "dear", "Vladimir")

# no space or separation char
print("Hi", "dear", "Vladimir", sep="")
print("Hi", "dear", "Vladimir", sep="%")

# line break
print("Hi", "\nVladimir", "\ndear")

# Exercise
print('I an learning Python using the course: \'Python Programming from ground level to Guru\'')
