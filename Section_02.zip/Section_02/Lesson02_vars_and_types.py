age = 57  # integer
print("Age : " + str(age))
print("Age :",       age)  # the same will be printed separated by a space

temper = 36.6  # float
print("Temperature", temper)

username = "Vlad"  # string
print("User name", username); print("User name", username)  # two commands in one line must be separated by ";"

IsExists = True  # boolean
print("Exists", IsExists)
IsExists = False  # boolean
print("Exists", IsExists)


# changing var type is allowed
temper = "37.3"
print("Temperature " + temper)

print ("Type : ", type(age))     # <class 'int'>
print ("Type : ", type(temper))  # <class 'str'>
print ("Type : ", type(3.62))    # <class 'float'>

