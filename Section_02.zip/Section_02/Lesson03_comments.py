# One lime comment
age = 57  # integer
print("Age : " + str(age))
print("Age :",       age)

# no multiline comments in Python, but ...
text = "line01\nline02\nline03"
print(text)
# the same (3 single or double quotes)
# example of multiline comment is below
'''
printing lines
one by
one
'''
# example of multiline text is below
text = """line01
line02
line03
line04"""
print(text)
