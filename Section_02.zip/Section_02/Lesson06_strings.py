mystr1 = "abc"
mysql2 = 'zxc'
print("mystr1 + mysql2 =", mystr1, mysql2)

# multiline
myText = '''string1
string2
string3
'''
print(myText)

#read input
number1 = input("Enter first number:")
print("You entered:", number1)
number2 = input("Enter second number:")
print("You entered:", number2)
print("Summ =", number1 + number2)  # strings
# print("Summ =", int(number1) + int(number2))
print("Summ =", float(number1) + float(number2))
